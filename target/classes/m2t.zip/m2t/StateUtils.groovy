import com.change_vision.jude.api.inf.model.IClass;

class StateUtils{
	def getAllState(){
		
	}
	
	def getInitialState(){
		
	}
}
